# Git Resource

Author: [Bob Jackman](https://github.com/kogi)

An extension for reading/writing global variable values

## Usage

```python
set_global('foo', some_value)
print(get_global('foo'))
unset_global('foo')
```
